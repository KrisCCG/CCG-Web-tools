<?php
/**
 * Title: Page — Home (all sections)
 * Slug: clickclick/page-home
 * Categories: clickclick, featured
 * Block Types: core/post-content
 * Post Types: page
 * Description: The whole homepage in one go: hero, two ways in, services, techniques, paper, how it works, labels.
 *
 * @package clickclick
 */

?>
<!-- wp:pattern {"slug":"clickclick/hero"} /-->

<!-- wp:pattern {"slug":"clickclick/two-ways"} /-->

<!-- wp:pattern {"slug":"clickclick/services"} /-->

<!-- wp:pattern {"slug":"clickclick/techniques"} /-->

<!-- wp:pattern {"slug":"clickclick/papers-teaser"} /-->

<!-- wp:pattern {"slug":"clickclick/how-it-works"} /-->

<!-- wp:pattern {"slug":"clickclick/labels-good-file"} /-->

