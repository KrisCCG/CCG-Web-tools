<?php
/**
 * Title: Home — paper teaser
 * Slug: clickclick/papers-teaser
 * Categories: clickclick
 * Description: Short paper section with paper chips and a button to the paper guide page.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:heading -->
<h2 class="wp-block-heading">Feel the paper first</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Colorplan, Sirio Ultra Black, recycled RecyStar and more. Choosing your paper is part of the job — and choosing it with us is free.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:list {"className":"is-style-cc-chips"} -->
<ul class="wp-block-list is-style-cc-chips">
<!-- wp:list-item -->
<li>Colorplan · 350 g</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Sirio Ultra Black · 280 g</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Vermilion · 300 g</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>MultiArt Silk · 115–400 g</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Biotop · 120–300 g</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>RecyStar Nature · 90–300 g</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo clickclick_papers_link(); ?>">Read the paper guide</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
