<?php
/**
 * Title: Header — info bar, logo, menu
 * Slug: clickclick/header
 * Categories: header, clickclick
 * Block Types: core/template-part/header
 * Description: Blue info bar (appointment, hours, address, languages), then the logo and the main menu. Texts come from inc/strings.php in EN/FR/NL.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"full","className":"is-style-cc-utility","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-cc-utility">
	<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"10px","bottom":"10px"},"blockGap":"0.5rem"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide" style="padding-top:10px;padding-bottom:10px">
		<!-- wp:paragraph -->
		<p><?php echo esc_html( clickclick_t( 'info_bar' ) ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:paragraph {"className":"cc-langs"} -->
		<p class="cc-langs"><?php echo wp_kses_post( clickclick_language_links() ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"border":{"bottom":{"color":"var:preset|color|accent-4","width":"1px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--accent-4);border-bottom-width:1px">
	<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)">
		<!-- wp:image {"width":"260px","sizeSlug":"full","linkDestination":"custom","style":{"border":{"radius":"0px"}}} -->
		<figure class="wp-block-image size-full is-resized has-custom-border"><a href="<?php echo esc_url( function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' ) ); ?>"><img src="<?php echo clickclick_asset( 'assets/images/logo-click-click-graphics.png' ); ?>" alt="<?php echo esc_attr( clickclick_t( 'logo_alt' ) ); ?>" style="border-radius:0px;width:260px"/></a></figure>
		<!-- /wp:image -->

		<!-- wp:navigation <?php echo clickclick_menu_attrs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON block attributes. ?> /-->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
