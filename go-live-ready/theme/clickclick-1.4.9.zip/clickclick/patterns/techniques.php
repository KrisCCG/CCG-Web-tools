<?php
/**
 * Title: Home — techniques band
 * Slug: clickclick/techniques
 * Categories: clickclick
 * Description: Cream band: "The last true printing shop" with six techniques (letterpress, hot foil, die-cutting, white toner, binding, big format).
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"full","className":"is-style-cc-band-cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-cc-band-cream" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">In-house · central Brussels</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">The last true printing shop in the heart of Brussels.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>A place where you can discuss ink and paper, the emotions behind a beautifully printed invitation, and the techniques best suited to your project.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%">
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Letterpress</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">In-house, for cards and invitations</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Hot foil</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Also holographic, combinable</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Die-cutting &amp; embossing</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Shapes and relief</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">White toner</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">On dark and coloured paper</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Binding</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Perfect, stapled, sewn, Wire-O</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Big format</h4>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Posters, boards, custom sizes</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
