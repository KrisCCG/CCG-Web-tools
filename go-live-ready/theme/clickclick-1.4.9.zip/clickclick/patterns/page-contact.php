<?php
/**
 * Title: Page — contact
 * Slug: clickclick/page-contact
 * Categories: clickclick, featured
 * Block Types: core/post-content
 * Post Types: page
 * Description: Contact page: the two routes first, then hours, address and e-mail.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--40)">
<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Shop it, or send us a request.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">We’re a small team, mostly at the presses. These two routes get you a price and a date faster than a phone call or an e-mail.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:pattern {"slug":"clickclick/two-ways"} /-->
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|70"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/check.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Opening hours</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Monday to Friday, 9:00–12:30 and 13:30–18:00. Closed on Saturday and Sunday. Workshop visits by appointment only.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/map.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">We are here</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Aalststraat 7–11 · Rue d'Alost 7–11<br>Brussel 1000 Bruxelles</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/envelope.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">E-mail</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Prefer e-mail, already know what you want, or need to send a file? info@clickclickgraphics.com</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
