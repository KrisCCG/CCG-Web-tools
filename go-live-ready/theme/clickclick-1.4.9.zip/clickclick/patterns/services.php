<?php
/**
 * Title: Home — what we do (3 services)
 * Slug: clickclick/services
 * Categories: clickclick, services
 * Description: Three white cards: Printing, Signage, Your project — photo, icon, text, chips and a link.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:heading -->
	<h2 class="wp-block-heading">What we do</h2>
	<!-- /wp:heading -->

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"is-style-cc-card","style":{"dimensions":{"minHeight":"100%"}},"layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-cc-card" style="min-height:100%">
				<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
				<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/book-open-green.jpg' ); ?>" alt="A printed book, open"/></figure>
				<!-- /wp:image -->

				<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
				<div class="wp-block-group">
					<!-- wp:heading {"level":3} -->
					<h3 class="wp-block-heading">Printing</h3>
					<!-- /wp:heading -->

					<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
					<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/map.svg' ); ?>" alt=""/></figure>
					<!-- /wp:image -->
				</div>
				<!-- /wp:group -->

				<!-- wp:paragraph -->
				<p>Cards, flyers, posters, brochures and books. Printed in our workshop or with trusted partners, and always checked by us.</p>
				<!-- /wp:paragraph -->

				<!-- wp:list {"className":"is-style-cc-chips"} -->
				<ul class="wp-block-list is-style-cc-chips">
					<!-- wp:list-item -->
					<li>Business cards</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Invitations</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Flyers &amp; folders</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Posters A3–A0</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Magazines</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Art books</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Stickers</li>
					<!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->

				<!-- wp:paragraph -->
				<p><a href="/en/printing/"><strong>All printing →</strong></a></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"is-style-cc-card","style":{"dimensions":{"minHeight":"100%"}},"layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-cc-card" style="min-height:100%">
				<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
				<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/signage-restaurant-wall.jpg' ); ?>" alt="Large prints installed on a restaurant wall"/></figure>
				<!-- /wp:image -->

				<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
				<div class="wp-block-group">
					<!-- wp:heading {"level":3} -->
					<h3 class="wp-block-heading">Signage</h3>
					<!-- /wp:heading -->

					<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
					<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/paper-roll.svg' ); ?>" alt=""/></figure>
					<!-- /wp:image -->
				</div>
				<!-- /wp:group -->

				<!-- wp:paragraph -->
				<p>Shop windows, banners, boards and wallpaper. Make your shopfront work for you — printed, cut and installed by us.</p>
				<!-- /wp:paragraph -->

				<!-- wp:list {"className":"is-style-cc-chips"} -->
				<ul class="wp-block-list is-style-cc-chips">
					<!-- wp:list-item -->
					<li>Window vinyl</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Banners</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Forex · Dibond</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Textile</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Wallpaper</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Hand-painted letters</li>
					<!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->

				<!-- wp:paragraph -->
				<p><a href="/en/signage/"><strong>All signage →</strong></a></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"is-style-cc-card","style":{"dimensions":{"minHeight":"100%"}},"layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-cc-card" style="min-height:100%">
				<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
				<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/paper-samples.jpg' ); ?>" alt="Paper and colour samples on a work table"/></figure>
				<!-- /wp:image -->

				<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
				<div class="wp-block-group">
					<!-- wp:heading {"level":3} -->
					<h3 class="wp-block-heading">Your project</h3>
					<!-- /wp:heading -->

					<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
					<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/speech-double.svg' ); ?>" alt=""/></figure>
					<!-- /wp:image -->
				</div>
				<!-- /wp:group -->

				<!-- wp:paragraph -->
				<p>Something complicated, like a book, an event or a wedding? We help you work out what you need before anything is printed.</p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph {"fontSize":"small"} -->
				<p class="has-small-font-size">Choosing your paper is on us. Working out a whole project with you is consulting — we'll tell you before we start.</p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph -->
				<p><a href="/en/your-project/"><strong>How we work on projects →</strong></a></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
