<?php
/**
 * Title: Home — labels and "A good file?"
 * Slug: clickclick/labels-good-file
 * Categories: clickclick
 * Description: White card with the Ecodynamique and Certified Craft labels, blue card linking to "A good file?".
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">Recognised</p>
<!-- /wp:paragraph -->
<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group">
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-label"} -->
<figure class="wp-block-image size-full is-style-cc-label"><img src="<?php echo clickclick_asset( 'assets/images/label-ecodynamique.png' ); ?>" alt="Ecodynamique label, Brussels-Capital Region"/></figure>
<!-- /wp:image -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-label"} -->
<figure class="wp-block-image size-full is-style-cc-label"><img src="<?php echo clickclick_asset( 'assets/images/label-certified-craft.png' ); ?>" alt="Certified Craft — Federal Artisan label"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Ecodynamique label (Brussels-Capital Region) and the Federal Artisan label — for ethical, artisanal and environmentally responsible printing.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"className":"is-style-cc-card-blue","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-cc-card-blue">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">Before you send</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">A good file?</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">How to prepare your file so it prints the way you imagined it. Not sure? Upload it with your order or request — we check every file before it goes on the press.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/en/good-file/">Check your file</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
