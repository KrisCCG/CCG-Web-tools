<?php
/**
 * Title: Home — two ways in (Shop / chat)
 * Slug: clickclick/two-ways
 * Categories: clickclick, call-to-action
 * Description: Two big cards that send simple orders to the shop and everything else to the request chat.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Two ways in</h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph -->
		<p>Something simple? Order it in the Shop. Something bigger or more complicated? Send a request through the chat — it collects everything we need, so we can answer you faster.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"is-style-cc-card-blue","layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-cc-card-blue">
				<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
				<p class="is-style-cc-kicker">01 · The Shop</p>
				<!-- /wp:paragraph -->

				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">Flyers, cards, posters. Price it, pay it, done.</h3>
				<!-- /wp:heading -->

				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item -->
					<li>See your price instantly, VAT included</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Pick your paper, upload your file</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Pay online with Bancontact</li>
					<!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->

				<!-- wp:buttons -->
				<div class="wp-block-buttons">
					<!-- wp:button {"className":"is-style-cc-shop","linkTarget":"_blank","rel":"noreferrer noopener"} -->
					<div class="wp-block-button is-style-cc-shop"><a class="wp-block-button__link wp-element-button" href="/shop/" target="_blank" rel="noreferrer noopener">Order online</a></div>
					<!-- /wp:button -->
				</div>
				<!-- /wp:buttons -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"is-style-cc-card-cream","layout":{"type":"default"}} -->
			<div class="wp-block-group is-style-cc-card-cream">
				<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
				<p class="is-style-cc-kicker">02 · Your project</p>
				<!-- /wp:paragraph -->

				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading">A book, an event, a wedding? Start with a request.</h3>
				<!-- /wp:heading -->

				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item -->
					<li>The chat asks for size, quantity, paper, deadline and file</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>We get one complete request and reply in writing</li>
					<!-- /wp:list-item -->

					<!-- wp:list-item -->
					<li>Quote with a time estimate — and a workshop meeting if your project needs one</li>
					<!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->

				<!-- wp:buttons -->
				<div class="wp-block-buttons">
					<!-- wp:button {"className":"is-style-cc-talk","linkTarget":"_blank","rel":"noreferrer noopener"} -->
					<div class="wp-block-button is-style-cc-talk"><a class="wp-block-button__link wp-element-button" href="/chat/" target="_blank" rel="noreferrer noopener">Let's talk</a></div>
					<!-- /wp:button -->
				</div>
				<!-- /wp:buttons -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
