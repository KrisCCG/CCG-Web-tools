<?php
/**
 * Title: Home — how it works (3 steps)
 * Slug: clickclick/how-it-works
 * Categories: clickclick
 * Description: Cream band with three numbered steps and icons.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"full","className":"is-style-cc-band-cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-cc-band-cream" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide">
<!-- wp:heading -->
<h2 class="wp-block-heading">How it works</h2>
<!-- /wp:heading -->
<!-- wp:columns {"className":"is-style-cc-steps"} -->
<div class="wp-block-columns is-style-cc-steps">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">01</p>
<!-- /wp:paragraph -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/speech.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Tell us what you need.</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>In the Shop for simple orders, in our chat for anything bigger.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">02</p>
<!-- /wp:paragraph -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/euro.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">We check our planning and send you a quote.</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>With an honest estimate of the time it takes.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"layout":{"type":"flex"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
<p class="is-style-cc-kicker">03</p>
<!-- /wp:paragraph -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/check.svg' ); ?>" alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">We make it.</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>You pick it up, or, in Brussels, we cycle it over when it fits on the cargo bike.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
