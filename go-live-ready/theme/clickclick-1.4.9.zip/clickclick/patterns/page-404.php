<?php
/**
 * Title: 404 — page not found
 * Slug: clickclick/page-404
 * Categories: clickclick
 * Inserter: no
 * Description: Big !! logo, our magnifier icon searching an empty folder, and a way home. Texts in EN/FR/NL from inc/strings.php.
 *
 * @package clickclick
 */

$home = function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' );
?>
<!-- wp:group {"align":"wide","className":"cc-404","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cc-404">
	<!-- wp:html -->
	<div class="cc-404__art" aria-hidden="true">
		<img class="cc-404__logo" src="<?php echo clickclick_asset( 'assets/images/exclamation-logo.svg' ); ?>" alt="">
		<img class="cc-404__search" src="<?php echo clickclick_asset( 'assets/icons/magnifier.svg' ); ?>" alt="">
		<img class="cc-404__folder" src="<?php echo clickclick_asset( 'assets/icons/folder.svg' ); ?>" alt="">
	</div>
	<!-- /wp:html -->

	<!-- wp:group {"className":"cc-404__text","layout":{"type":"default"}} -->
	<div class="wp-block-group cc-404__text">
		<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
		<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( '404_kicker' ) ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1} -->
		<h1 class="wp-block-heading"><?php echo esc_html( clickclick_t( '404_title' ) ); ?></h1>
		<!-- /wp:heading -->



		<!-- wp:paragraph {"className":"cc-404__home"} -->
		<p class="cc-404__home"><a href="<?php echo esc_url( $home ); ?>">← <?php echo esc_html( clickclick_t( '404_home' ) ); ?></a></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
