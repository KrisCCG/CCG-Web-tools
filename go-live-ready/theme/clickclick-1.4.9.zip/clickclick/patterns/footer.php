<?php
/**
 * Title: Footer — shop or request, hours, contact, address
 * Slug: clickclick/footer
 * Categories: footer, clickclick
 * Block Types: core/template-part/footer
 * Description: Texts come from inc/strings.php in EN/FR/NL. Cream footer with the two routes (shop / chat), opening hours, pick-up, contact, address, social links and legal links.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"full","className":"is-style-cc-band-cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-cc-band-cream" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:heading {"fontSize":"xx-large"} -->
		<h2 class="wp-block-heading has-xx-large-font-size"><?php echo esc_html( clickclick_t( 'cta_lead' ) ); ?> <mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-accent-1-color"><?php echo esc_html( clickclick_t( 'cta_accent' ) ); ?></mark></h2>
		<!-- /wp:heading -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"className":"is-style-cc-shop","linkTarget":"_blank","rel":"noreferrer noopener"} -->
			<div class="wp-block-button is-style-cc-shop"><a class="wp-block-button__link wp-element-button" href="<?php echo clickclick_tool_link( 'shop' ); ?>" target="_blank" rel="noreferrer noopener"><?php echo esc_html( clickclick_t( 'btn_order' ) ); ?></a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-cc-talk","linkTarget":"_blank","rel":"noreferrer noopener"} -->
			<div class="wp-block-button is-style-cc-talk"><a class="wp-block-button__link wp-element-button" href="<?php echo clickclick_tool_link( 'chat' ); ?>" target="_blank" rel="noreferrer noopener"><?php echo esc_html( clickclick_t( 'btn_talk' ) ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->

	<!-- wp:separator {"align":"wide"} -->
	<hr class="wp-block-separator alignwide has-alpha-channel-opacity"/>
	<!-- /wp:separator -->

	<!-- wp:columns {"align":"wide","fontSize":"small"} -->
	<div class="wp-block-columns alignwide has-small-font-size">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
			<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/check.svg' ); ?>" alt=""/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
			<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( 'hours_title' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p><?php echo wp_kses_post( clickclick_t( 'hours_text' ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
			<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/arrow-down.svg' ); ?>" alt=""/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
			<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( 'pickup_title' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p><?php echo esc_html( clickclick_t( 'pickup_text' ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
			<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/envelope.svg' ); ?>" alt=""/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
			<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( 'contact_title' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p><?php echo wp_kses_post( sprintf( clickclick_t( 'contact_text' ), clickclick_tool_link( 'shop' ), clickclick_tool_link( 'chat' ) ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
			<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/map.svg' ); ?>" alt=""/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
			<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( 'here_title' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p>Aalststraat 7–11 · Rue d'Alost 7–11<br>Brussel 1000 Bruxelles<br><a href="https://www.openstreetmap.org/search?query=Rue%20d%27Alost%207%2C%201000%20Bruxelles"><?php echo esc_html( clickclick_t( 'maps' ) ); ?></a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"is-style-cc-icon"} -->
			<figure class="wp-block-image size-full is-style-cc-icon"><img src="<?php echo clickclick_asset( 'assets/icons/heart.svg' ); ?>" alt=""/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
			<p class="is-style-cc-kicker"><?php echo esc_html( clickclick_t( 'follow_title' ) ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p><a href="https://www.instagram.com/clickclickgraphics">Instagram @clickclickgraphics</a><br><a href="https://www.facebook.com/clickclickgraphics">Facebook clickclickgraphics</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"align":"wide"} -->
	<hr class="wp-block-separator alignwide has-alpha-channel-opacity"/>
	<!-- /wp:separator -->

	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:paragraph {"className":"is-style-cc-mono","fontSize":"small"} -->
		<p class="is-style-cc-mono has-small-font-size">© Click Click Graphics SRL · Brussels</p>
		<!-- /wp:paragraph -->

		<!-- wp:paragraph {"className":"is-style-cc-mono","fontSize":"small"} -->
		<p class="is-style-cc-mono has-small-font-size"><a href="<?php echo clickclick_link( 'legal_slug' ); ?>"><?php echo esc_html( clickclick_t( 'legal' ) ); ?></a> · <a href="<?php echo clickclick_papers_link(); ?>"><?php echo esc_html( clickclick_t( 'papers' ) ); ?></a></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
