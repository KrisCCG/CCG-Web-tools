<?php
/**
 * Title: Page — service page (Printing, Signage, …)
 * Slug: clickclick/page-service
 * Categories: clickclick, featured
 * Block Types: core/post-content
 * Post Types: page
 * Description: Service page: tagline, intro, product chips, photo, then the two ways in. The page title is shown above it automatically.
 *
 * @package clickclick
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--40)">
<!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">We print, we cut, we fold, we bind. You bring the idea.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Tell us what it’s for, and we’ll tell you what works.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"55%"} -->
<div class="wp-block-column" style="flex-basis:55%">
<!-- wp:paragraph -->
<p>Since 2016, Click Click Graphics has operated its own printing facilities in central Brussels. [Replace with the intro text for this page.]</p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"is-style-cc-chips"} -->
<ul class="wp-block-list is-style-cc-chips">
<!-- wp:list-item -->
<li>Business cards</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Invitations and greeting cards</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Flyers and folders</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Posters</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Catalogues, leaflets and magazines</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Art books and novels</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Luxe and letterpress</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Big format</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Stickers and packaging</li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%">
<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/book-open-green.jpg' ); ?>" alt="A printed book, open"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
<!-- wp:pattern {"slug":"clickclick/two-ways"} /-->
