<?php
/**
 * Title: Home — hero with collage
 * Slug: clickclick/hero
 * Categories: clickclick, banner
 * Description: Big headline with the !! logo, intro, Order online / Let's talk buttons and a photo collage.
 *
 * @package clickclick
 */

?>
<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"},"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
	<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%">
		<!-- wp:paragraph {"className":"is-style-cc-kicker"} -->
		<p class="is-style-cc-kicker">Print workshop · Brussels · since 2016</p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1} -->
		<h1 class="wp-block-heading"><img class="wp-image-0" style="width: 70px;" src="<?php echo clickclick_asset( 'assets/images/exclamation-logo.svg' ); ?>" alt="!!"> We love paper, ink and a job well done.</h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"fontSize":"large"} -->
		<p class="has-large-font-size">A print workshop in Brussels, for everything from flyers to art books. Three of us, our own presses and a real love for paper.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"className":"is-style-cc-shop","linkTarget":"_blank","rel":"noreferrer noopener"} -->
			<div class="wp-block-button is-style-cc-shop"><a class="wp-block-button__link wp-element-button" href="/shop/" target="_blank" rel="noreferrer noopener">Order online</a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-cc-talk","linkTarget":"_blank","rel":"noreferrer noopener"} -->
			<div class="wp-block-button is-style-cc-talk"><a class="wp-block-button__link wp-element-button" href="/chat/" target="_blank" rel="noreferrer noopener">Let's talk</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

		<!-- wp:paragraph {"className":"is-style-cc-mono","fontSize":"small"} -->
		<p class="is-style-cc-mono has-small-font-size">✓ Prices and payment online · ✓ Pick up in the workshop · ✓ Cargo-bike delivery in Brussels</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:column -->

	<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
	<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">
		<!-- wp:gallery {"columns":2,"linkTo":"none","sizeSlug":"large","className":"is-style-cc-collage"} -->
		<figure class="wp-block-gallery has-nested-images columns-2 is-cropped is-style-cc-collage">
			<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
			<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/letterpress-greeting-card.jpg' ); ?>" alt="Letterpress greeting card"/></figure>
			<!-- /wp:image -->

			<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
			<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/wedding-invitation.jpg' ); ?>" alt="Wedding invitation"/></figure>
			<!-- /wp:image -->

			<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
			<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/book-open-pink.jpg' ); ?>" alt="Printed book, open"/></figure>
			<!-- /wp:image -->

			<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
			<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/printed-cards.jpg' ); ?>" alt="Printed cards with punched holes"/></figure>
			<!-- /wp:image -->

			<!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
			<figure class="wp-block-image size-large"><img src="<?php echo clickclick_asset( 'assets/images/leaflets-posters.jpg' ); ?>" alt="Printed leaflets and posters"/></figure>
			<!-- /wp:image -->
		</figure>
		<!-- /wp:gallery -->
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
