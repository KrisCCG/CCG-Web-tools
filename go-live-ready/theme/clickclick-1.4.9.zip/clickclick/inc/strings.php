<?php
/**
 * Texts shown in the header and footer, in EN / FR / NL.
 *
 * The header and footer are shared by every page, so their words can't be
 * typed per page. They live here instead. The right language is picked from
 * Polylang (or from the site language when Polylang is not active).
 *
 * FR and NL: first draft, to be checked by a native reader before launch.
 * To change a text: edit it here (all three languages), then upload this file.
 *
 * @package clickclick
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Current language code: 'en', 'fr' or 'nl'.
 *
 * @return string
 */
function clickclick_lang() {
	$lang = '';
	if ( function_exists( 'pll_current_language' ) ) {
		$lang = (string) pll_current_language( 'slug' );
	}
	if ( '' === $lang ) {
		$lang = substr( get_locale(), 0, 2 );
	}
	return in_array( $lang, array( 'en', 'fr', 'nl' ), true ) ? $lang : 'en';
}

/**
 * Translated text for the header and footer.
 *
 * @param string $key Text key.
 * @return string
 */
function clickclick_t( $key ) {
	static $texts = array(
		'info_bar'      => array(
			'en' => 'By appointment only · Mon–Fri 9:00–12:30 · 13:30–18:00 · Aalststraat 7–11, 1000 Brussels',
			'fr' => 'Uniquement sur rendez-vous · Lun–ven 9h00–12h30 · 13h30–18h00 · Rue d’Alost 7–11, 1000 Bruxelles',
			'nl' => 'Enkel op afspraak · Ma–vr 9u00–12u30 · 13u30–18u00 · Aalststraat 7–11, 1000 Brussel',
		),
		'logo_alt'      => array(
			'en' => 'Click Click Graphics — home',
			'fr' => 'Click Click Graphics — accueil',
			'nl' => 'Click Click Graphics — home',
		),
		'cta_lead'      => array(
			'en' => 'Shop it, or',
			'fr' => 'Commandez en ligne, ou',
			'nl' => 'Bestel online, of',
		),
		'cta_accent'    => array(
			'en' => 'send us a request.',
			'fr' => 'envoyez-nous une demande.',
			'nl' => 'stuur ons een aanvraag.',
		),
		'btn_order'     => array(
			'en' => 'Order online',
			'fr' => 'Commander',
			'nl' => 'Bestel online',
		),
		'btn_talk'      => array(
			'en' => 'Let’s talk',
			'fr' => 'Parlons-en',
			'nl' => 'Laten we praten',
		),
		'hours_title'   => array(
			'en' => 'Opening hours',
			'fr' => 'Heures d’ouverture',
			'nl' => 'Openingsuren',
		),
		'hours_text'    => array(
			'en' => 'Monday to Friday<br>9:00–12:30 and 13:30–18:00<br>Closed on Saturday and Sunday.<br>Workshop visits by appointment only.',
			'fr' => 'Du lundi au vendredi<br>9h00–12h30 et 13h30–18h00<br>Fermé le samedi et le dimanche.<br>Visites de l’atelier uniquement sur rendez-vous.',
			'nl' => 'Maandag tot vrijdag<br>9u00–12u30 en 13u30–18u00<br>Gesloten op zaterdag en zondag.<br>Bezoek aan het atelier enkel op afspraak.',
		),
		'pickup_title'  => array(
			'en' => 'Picking up your order',
			'fr' => 'Retirer votre commande',
			'nl' => 'Je bestelling afhalen',
		),
		'pickup_text'   => array(
			'en' => 'Shop orders can be picked up during opening hours. Just let us know when you’re coming — we’re a small team, sometimes at the presses or out on a job.',
			'fr' => 'Les commandes de la boutique se retirent pendant les heures d’ouverture. Prévenez-nous simplement de votre passage — nous sommes une petite équipe, parfois aux presses ou en route pour un chantier.',
			'nl' => 'Bestellingen uit de shop kun je afhalen tijdens de openingsuren. Laat ons gewoon weten wanneer je komt — we zijn een klein team, soms aan de persen of op verplaatsing.',
		),
		'contact_title' => array(
			'en' => 'Contact',
			'fr' => 'Contact',
			'nl' => 'Contact',
		),
		'contact_text'  => array(
			'en' => 'Simple orders: the <a href="%1$s" target="_blank" rel="noopener">Shop</a>.<br>Everything else: the <a href="%2$s" target="_blank" rel="noopener">request chat</a> — it sends us one complete request.<br>info@clickclickgraphics.com',
			'fr' => 'Commandes simples : la <a href="%1$s" target="_blank" rel="noopener">boutique</a>.<br>Tout le reste : le <a href="%2$s" target="_blank" rel="noopener">chat</a> — il nous envoie une demande complète.<br>info@clickclickgraphics.com',
			'nl' => 'Eenvoudige bestellingen: de <a href="%1$s" target="_blank" rel="noopener">shop</a>.<br>Al de rest: de <a href="%2$s" target="_blank" rel="noopener">aanvraagchat</a> — die stuurt ons één volledige aanvraag.<br>info@clickclickgraphics.com',
		),
		'here_title'    => array(
			'en' => 'We are here',
			'fr' => 'Nous sommes ici',
			'nl' => 'Hier vind je ons',
		),
		'maps'          => array(
			'en' => 'Open in maps',
			'fr' => 'Ouvrir une carte',
			'nl' => 'Open in kaart',
		),
		'follow_title'  => array(
			'en' => 'Follow',
			'fr' => 'Suivez-nous',
			'nl' => 'Volg ons',
		),
		'404_kicker'    => array(
			'en' => 'Error 404 · misprint',
			'fr' => 'Erreur 404 · gâche',
			'nl' => 'Fout 404 · misdruk',
		),
		'404_title'     => array(
			'en' => 'This page only exists in someone’s dreams.',
			'fr' => 'Cette page n’existe que dans les rêves de quelqu’un.',
			'nl' => 'Deze pagina bestaat alleen in iemands dromen.',
		),
		'404_text'      => array(
			'en' => 'This page only exists in someone’s dreams.',
			'fr' => 'Cette page n’existe que dans les rêves de quelqu’un.',
			'nl' => 'Deze pagina bestaat alleen in iemands dromen.',
		),
		'404_bubble'    => array(
			'en' => 'Where’s my ink?!',
			'fr' => 'Où est mon encre ?!',
			'nl' => 'Waar is mijn inkt?!',
		),
		'404_home'      => array(
			'en' => 'Back to the homepage',
			'fr' => 'Retour à l’accueil',
			'nl' => 'Terug naar de startpagina',
		),
		'legal'         => array(
			'en' => 'Legal and privacy',
			'fr' => 'Mentions légales et vie privée',
			'nl' => 'Juridisch en privacy',
		),
		'papers'        => array(
			'en' => 'Paper guide',
			'fr' => 'Guide des papiers',
			'nl' => 'Papiergids',
		),
		'legal_slug'    => array(
			'en' => 'legal',
			'fr' => 'mentions-legales',
			'nl' => 'juridisch',
		),
		'papers_slug'   => array(
			'en' => 'paper-guide',
			'fr' => 'guide-des-papiers',
			'nl' => 'papiergids',
		),
	);

	if ( ! isset( $texts[ $key ] ) ) {
		return $key;
	}
	$lang = clickclick_lang();
	return isset( $texts[ $key ][ $lang ] ) ? $texts[ $key ][ $lang ] : $texts[ $key ]['en'];
}

/**
 * Link to a page of the site in the current language, e.g. clickclick_link( 'papers_slug' ).
 *
 * @param string $slug_key Key of a *_slug text above.
 * @return string
 */
function clickclick_link( $slug_key ) {
	$home = function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' );
	return esc_url( trailingslashit( $home ) . clickclick_t( $slug_key ) . '/' );
}

/**
 * Shop and chat links (separate folders on clickclick.be), with the language passed on.
 *
 * @param string $which 'shop' or 'chat'.
 * @return string
 */
function clickclick_shop_path() {
	// Which shop the website links to. The new shop lives at /shop/ since go-live.
	return 'shop';
}

function clickclick_tool_link( $which ) {
	if ( 'chat' === $which ) {
		return esc_url( clickclick_apps_origin() . '/chat/#lang=' . clickclick_lang() );
	}
	return esc_url( clickclick_apps_origin() . '/' . clickclick_shop_path() . '/?lang=' . clickclick_lang() );
}

/**
 * Where the stand-alone apps (shop, chat, paper guide) live: always on clickclick.be.
 * While this WordPress runs elsewhere (the preview), links must point there in full;
 * once WordPress itself runs on clickclick.be this returns '' and links stay relative.
 *
 * @return string
 */
function clickclick_apps_origin() {
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	return in_array( $host, array( 'clickclick.be', 'www.clickclick.be' ), true ) ? '' : 'https://clickclick.be';
}

/**
 * Paper guide (stand-alone pages on clickclick.be, one file per language).
 *
 * @return string
 */
function clickclick_papers_link() {
	// Paper guide lives in WordPress (Oct 2026): one page per language.
	$slug = array( 'en' => 'paper-guide', 'fr' => 'guide-des-papiers', 'nl' => 'papiergids' );
	$lang = clickclick_lang();
	$page = get_page_by_path( $slug[ $lang ] ?? 'paper-guide' );
	if ( $page && 'publish' === $page->post_status ) {
		return esc_url( get_permalink( $page ) );
	}
	// Fallback while the pages do not exist yet: the old static guide.
	$file = array( 'en' => '', 'fr' => 'fr.html', 'nl' => 'nl.html' );
	return esc_url( clickclick_apps_origin() . '/papers/' . ( $file[ $lang ] ?? '' ) );
}

/**
 * Menu for the current language.
 *
 * Polylang free does not translate menus in a block theme, so the theme does it:
 * make three menus in Appearance → Editor → Navigation, named exactly
 * "Menu EN", "Menu FR" and "Menu NL". The header shows the one for the page's language.
 * If no menu with that name exists, WordPress falls back to its default (a list of pages).
 *
 * @return int Menu (wp_navigation post) ID, or 0.
 */
function clickclick_menu_id() {
	$title = 'Menu ' . strtoupper( clickclick_lang() );
	$menus = get_posts(
		array(
			'post_type'      => 'wp_navigation',
			'post_status'    => 'publish',
			'title'          => $title,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'lang'           => '', // Polylang: don't filter menus by language.
		)
	);
	return $menus ? (int) $menus[0] : 0;
}

/**
 * Attributes for the navigation block in the header (JSON).
 *
 * @return string
 */
function clickclick_menu_attrs() {
	$attrs = array(
		'overlayBackgroundColor' => 'base',
		'overlayTextColor'       => 'contrast',
		'layout'                 => array(
			'type'           => 'flex',
			'justifyContent' => 'right',
			'flexWrap'       => 'wrap',
		),
	);
	$id = clickclick_menu_id();
	if ( $id ) {
		$attrs = array( 'ref' => $id ) + $attrs;
	}
	return wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES );
}
