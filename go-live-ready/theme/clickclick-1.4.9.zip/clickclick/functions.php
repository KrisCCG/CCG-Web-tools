<?php
/**
 * Click Click Graphics — child theme of Twenty Twenty-Five.
 *
 * What this file does:
 * - loads the child theme's style.css on the site and in the editor;
 * - registers the block styles used by the patterns (buttons, cards, chips…);
 * - adds a "Click Click" category so the patterns are easy to find.
 *
 * @package clickclick
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_theme_file_path( 'inc/strings.php' );

/**
 * Language links for the info bar: EN · FR · NL, linking to the translation of the current page.
 * Uses Polylang when active; without Polylang it shows the codes without links.
 *
 * @return string HTML.
 */
function clickclick_language_links() {
	if ( ! function_exists( 'pll_the_languages' ) ) {
		return 'EN · FR · NL';
	}
	$langs = pll_the_languages( array( 'raw' => 1, 'hide_if_empty' => 0 ) );
	$out   = array();
	foreach ( (array) $langs as $l ) {
		$current = ! empty( $l['current_lang'] ) ? ' aria-current="page"' : '';
		$out[]   = '<a href="' . esc_url( $l['url'] ) . '"' . $current . '>' . esc_html( strtoupper( $l['slug'] ) ) . '</a>';
	}
	return implode( ' · ', $out );
}

/**
 * Site: load the child stylesheet after the parent's.
 */
function clickclick_enqueue_styles() {
	wp_enqueue_style(
		'clickclick-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);
	wp_enqueue_script(
		'clickclick-hero-logo',
		get_theme_file_uri( 'assets/js/hero-logo.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true, 'strategy' => 'defer' )
	);
	wp_enqueue_script(
		'clickclick-jumpbar',
		get_theme_file_uri( 'assets/js/jumpbar.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true, 'strategy' => 'defer' )
	);
	wp_enqueue_script(
		'clickclick-duo',
		get_theme_file_uri( 'assets/js/duo.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true, 'strategy' => 'defer' )
	);
	wp_enqueue_script(
		'clickclick-slideshow',
		get_theme_file_uri( 'assets/js/slideshow.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true, 'strategy' => 'defer' )
	);
}
add_action( 'wp_enqueue_scripts', 'clickclick_enqueue_styles', 20 );

/**
 * Editor: show the same styles while editing.
 */
function clickclick_editor_style() {
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'clickclick_editor_style', 20 );

/**
 * Block styles. Editors pick these in the block sidebar under "Styles".
 */
function clickclick_register_block_styles() {
	$styles = array(
		'core/button'    => array(
			'cc-shop' => __( 'Order online (basket)', 'clickclick' ),
			'cc-talk' => __( "Let's talk (chat)", 'clickclick' ),
		),
		'core/group'     => array(
			'cc-card'       => __( 'White card', 'clickclick' ),
			'cc-card-blue'  => __( 'Blue card', 'clickclick' ),
			'cc-card-cream' => __( 'Cream card', 'clickclick' ),
			'cc-dashed'     => __( 'Dashed box', 'clickclick' ),
			'cc-utility'    => __( 'Blue info bar', 'clickclick' ),
			'cc-band-cream' => __( 'Cream band', 'clickclick' ),
			'cc-band-line'  => __( 'Band with lines', 'clickclick' ),
			'cc-compact'    => __( 'Compact text (legal, terms)', 'clickclick' ),
			'cc-note'       => __( 'Note box', 'clickclick' ),
		),
		'core/heading'   => array(
			'cc-small' => __( 'Small heading', 'clickclick' ),
			'cc-label' => __( 'Small label (capitals)', 'clickclick' ),
		),
		'core/table'     => array(
			'cc-dl' => __( 'Details (label + text)', 'clickclick' ),
		),
		'core/paragraph' => array(
			'cc-kicker' => __( 'Small blue label', 'clickclick' ),
			'cc-mono'   => __( 'Mono capitals', 'clickclick' ),
		),
		'core/list'      => array(
			'cc-chips' => __( 'Chips', 'clickclick' ),
			'cc-toc'   => __( 'Contents (numbered, 2 columns)', 'clickclick' ),
			'cc-jumpnav' => __( 'Section bar (sticky, at top)', 'clickclick' ),
		),
		'core/image'     => array(
			'cc-icon'  => __( 'Icon', 'clickclick' ),
			'cc-label' => __( 'Label / logo', 'clickclick' ),
		),
		'core/gallery'   => array(
			'cc-collage'   => __( 'Collage', 'clickclick' ),
			'cc-slideshow' => __( 'Slideshow (with counter)', 'clickclick' ),
			'cc-duo'       => __( 'Two at a time (rotating)', 'clickclick' ),
		),
		'core/columns'   => array(
			'cc-steps' => __( 'Numbered steps', 'clickclick' ),
		),
	);

	foreach ( $styles as $block => $variations ) {
		foreach ( $variations as $name => $label ) {
			register_block_style(
				$block,
				array(
					'name'  => $name,
					'label' => $label,
				)
			);
		}
	}
}
add_action( 'init', 'clickclick_register_block_styles' );

/**
 * Pattern category for the Click Click patterns.
 */
function clickclick_pattern_categories() {
	register_block_pattern_category(
		'clickclick',
		array(
			'label'       => __( 'Click Click', 'clickclick' ),
			'description' => __( 'Sections and page layouts for the Click Click Graphics site.', 'clickclick' ),
		)
	);
}
add_action( 'init', 'clickclick_pattern_categories' );

/**
 * Helper for patterns: URL of a file inside this theme.
 *
 * @param string $path Path relative to the theme folder.
 * @return string
 */
function clickclick_asset( $path ) {
	return esc_url( get_theme_file_uri( $path ) );
}

/**
 * SVG uploads (vector drawings, icons), for administrators only.
 *
 * WordPress blocks SVG by default because an SVG file can contain code.
 * Only users who can manage the site may upload them, and files that contain
 * scripts, event handlers or external references are refused.
 */
function clickclick_svg_mimes( $mimes ) {
	if ( current_user_can( 'manage_options' ) ) {
		$mimes['svg'] = 'image/svg+xml';
	}
	return $mimes;
}
add_filter( 'upload_mimes', 'clickclick_svg_mimes' );

function clickclick_svg_filetype( $data, $file, $filename, $mimes ) {
	if ( current_user_can( 'manage_options' ) && 'svg' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
		$data['ext']  = 'svg';
		$data['type'] = 'image/svg+xml';
	}
	return $data;
}
add_filter( 'wp_check_filetype_and_ext', 'clickclick_svg_filetype', 10, 4 );

function clickclick_svg_check( $file ) {
	if ( isset( $file['name'] ) && 'svg' === strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) ) ) {
		$svg = file_get_contents( $file['tmp_name'] );
		if ( false === $svg || preg_match( '/<script|<foreignObject|\son[a-z]+\s*=|javascript:|<!ENTITY|xlink:href\s*=\s*["\']\s*(?!#)|\shref\s*=\s*["\']\s*(?!#)/i', $svg ) ) {
			$file['error'] = __( 'This SVG contains scripts or external links and was refused. Export it again as a plain SVG.', 'clickclick' );
		}
	}
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'clickclick_svg_check' );


/**
 * Links in page content to the apps (/shop/, /chat/, /papers/) live on clickclick.be.
 * While WordPress runs on the preview domain, make them absolute so they keep working.
 */
function clickclick_absolute_app_links( $html ) {
	if ( false === strpos( $html, 'href="/' ) ) {
		return $html;
	}
	$html   = preg_replace( '#href="/flyers(/|")#', 'href="/shop$1', $html ); // shop moved to /shop/ (Oct 2026)
	// All shop links in the pages say /shop/; send them to the shop chosen in clickclick_shop_path().
	$html   = preg_replace( '#href="/shop(/|")#', 'href="/' . clickclick_shop_path() . '$1', $html );
	$origin = clickclick_apps_origin();
	if ( '' === $origin ) {
		return $html;
	}
	return preg_replace( '#href="/(shop-v2|shop|chat|papers)(/|")#', 'href="' . $origin . '/$1$2', $html );
}
add_filter( 'render_block', 'clickclick_absolute_app_links' );


/**
 * Menu: the link to the (language) homepage shows a little house instead of its label.
 * The label stays for screen readers and as tooltip.
 */
function clickclick_home_icon_link( $html, $block ) {
	if ( 'core/navigation-link' !== ( $block['blockName'] ?? '' ) ) {
		return $html;
	}
	$url  = $block['attrs']['url'] ?? '';
	$path = trailingslashit( strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( $host && wp_parse_url( home_url(), PHP_URL_HOST ) !== $host ) {
		return $html;
	}
	$homes = array( trailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ), '/en/', '/fr/', '/nl/' );
	if ( function_exists( 'pll_languages_list' ) ) {
		foreach ( pll_languages_list() as $slug ) {
			$homes[] = trailingslashit( (string) wp_parse_url( pll_home_url( $slug ), PHP_URL_PATH ) );
			$homes[] = '/' . $slug . '/';
		}
	}
	if ( ! in_array( $path, $homes, true ) ) {
		return $html;
	}
	$label = wp_strip_all_tags( $block['attrs']['label'] ?? 'Home' );
	$svg   = '<svg class="cc-home-icon" aria-hidden="true" focusable="false" viewBox="0 0 100 90"><g fill="none" stroke="currentColor" stroke-width="7" stroke-linejoin="round" stroke-linecap="round" transform="skewX(-12) translate(16 0)"><path d="M12 42 50 10l38 32"/><path d="M22 34v44h56V34"/><path d="M42 78V56h16v22"/></g></svg>';
	$html  = preg_replace(
		'#<span class="wp-block-navigation-item__label">.*?</span>#s',
		$svg . '<span class="screen-reader-text">' . esc_html( $label ) . '</span>',
		$html,
		1
	);
	return preg_replace( '#<a #', '<a title="' . esc_attr( $label ) . '" ', $html, 1 );
}
add_filter( 'render_block', 'clickclick_home_icon_link', 10, 2 );


/**
 * Browser tab / bookmark icon: the !! logo.
 * Only used while no Site Icon is set in WordPress (that setting wins if someone sets one).
 */
function clickclick_favicon() {
	if ( has_site_icon() ) {
		return;
	}
	$base = get_stylesheet_directory_uri() . '/assets/images/';
	$v    = wp_get_theme()->get( 'Version' );
	printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( $base . 'favicon.svg?v=' . $v ) );
	printf( '<link rel="icon" href="%s" sizes="32x32" type="image/png">' . "\n", esc_url( $base . 'favicon-32.png?v=' . $v ) );
	printf( '<link rel="apple-touch-icon" href="%s">' . "\n", esc_url( $base . 'favicon-180.png?v=' . $v ) );
}
add_action( 'wp_head', 'clickclick_favicon', 2 );
add_action( 'login_head', 'clickclick_favicon' );
add_action( 'admin_head', 'clickclick_favicon' );


/**
 * Maintenance mode ("Lunch at Nona").
 * Switch: Settings → General → "Maintenance mode". While on, visitors who are not logged in
 * get maintenance.html (theme folder) with status 503; logged-in users see the normal site.
 * wp-admin, login, REST, cron and AJAX keep working.
 */
function clickclick_maintenance_setting() {
	register_setting( 'general', 'clickclick_maintenance', array(
		'type'              => 'boolean',
		'sanitize_callback' => 'rest_sanitize_boolean',
		'default'           => false,
	) );
	add_settings_field(
		'clickclick_maintenance',
		'Maintenance mode',
		function () {
			printf(
				'<label><input type="checkbox" name="clickclick_maintenance" value="1" %s> Show the maintenance page to visitors (logged-in users still see the site)</label>',
				checked( (bool) get_option( 'clickclick_maintenance' ), true, false )
			);
			$flag = clickclick_maintenance_flag_path();
			$on   = file_exists( $flag );
			printf(
				'<p class="description">Shop &amp; chat (clickclick.be/shop, /chat): <strong>%s</strong>%s</p>',
				$on ? 'maintenance page ON' : 'normal',
				is_writable( dirname( $flag ) ) ? '' : ' — WordPress cannot write to ' . esc_html( dirname( $flag ) ) . ', so shop &amp; chat must be switched by hand (create/delete maintenance.on there).'
			);
		},
		'general'
	);
}
add_action( 'admin_init', 'clickclick_maintenance_setting' );

function clickclick_maintenance_gate() {
	if ( ! get_option( 'clickclick_maintenance' ) || is_user_logged_in() ) {
		return;
	}
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	$file = get_stylesheet_directory() . '/maintenance.html';
	if ( ! is_readable( $file ) ) {
		return;
	}
	status_header( 503 );
	header( 'Retry-After: 3600' );
	header( 'Content-Type: text/html; charset=utf-8' );
	nocache_headers();
	readfile( $file );
	exit;
}
add_action( 'template_redirect', 'clickclick_maintenance_gate', 0 );

function clickclick_maintenance_adminbar( $bar ) {
	if ( get_option( 'clickclick_maintenance' ) && current_user_can( 'manage_options' ) ) {
		$bar->add_node( array(
			'id'    => 'cc-maintenance',
			'title' => '🍝 Maintenance ON',
			'href'  => admin_url( 'options-general.php' ),
		) );
	}
}
add_action( 'admin_bar_menu', 'clickclick_maintenance_adminbar', 100 );


/**
 * Shop & chat follow the same switch: they show their own maintenance.html while
 * the file maintenance.on exists in the clickclick.be web root (see their .htaccess).
 * WordPress (preview.clickclick.be, same Infomaniak account) creates/removes it.
 * Override the location with define( 'CLICKCLICK_MAINTENANCE_FLAG', '/path/maintenance.on' ).
 */
function clickclick_maintenance_flag_path() {
	if ( defined( 'CLICKCLICK_MAINTENANCE_FLAG' ) ) {
		return CLICKCLICK_MAINTENANCE_FLAG;
	}
	return dirname( ABSPATH ) . '/clickclick.be/maintenance.on';
}

function clickclick_maintenance_sync( $on ) {
	$flag = clickclick_maintenance_flag_path();
	if ( ! is_dir( dirname( $flag ) ) ) {
		return;
	}
	if ( $on ) {
		@file_put_contents( $flag, 'Maintenance switched on in WordPress on ' . gmdate( 'c' ) . "\n" );
	} elseif ( file_exists( $flag ) ) {
		@unlink( $flag );
	}
}
add_action( 'update_option_clickclick_maintenance', function ( $old, $new ) { clickclick_maintenance_sync( (bool) $new ); }, 10, 2 );
add_action( 'add_option_clickclick_maintenance', function ( $name, $value ) { clickclick_maintenance_sync( (bool) $value ); }, 10, 2 );


/**
 * Photo cards (technique tiles with a background image): same CSS on the site and in the editor.
 */
add_action( 'enqueue_block_assets', function () {
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'clickclick-photo-cards', get_stylesheet_directory_uri() . '/assets/css/photo-cards.css', array(), $v );
	// The editor canvas (iframe) does not reliably pick up add_editor_style() in recent WordPress,
	// so load the theme stylesheet there too: cards, bands and buttons look the same while editing.
	if ( is_admin() ) {
		wp_enqueue_style( 'clickclick-editor-theme', get_stylesheet_uri(), array(), $v );
	}
}, 20 );
