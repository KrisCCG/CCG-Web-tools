/**
 * "Two at a time" galleries (core/gallery, is-style-cc-duo):
 * shows two big photos side by side and fades to the next pair every few seconds.
 * No arrows; small dots show where you are. Stops when the visitor prefers reduced motion.
 *
 * - Photos keep their srcset, so the browser picks a sharp size for the frame
 *   (also when the gallery itself was set to a small "Resolution").
 * - All photos are fetched as soon as the gallery comes near the screen (no lazy waiting).
 * - The clock starts when the gallery is on screen, and only moves on to a pair that is loaded.
 */
( function () {
	var DELAY = 4000;
	var SIZES = '(max-width: 781px) 50vw, 640px';

	function setup( gallery ) {
		if ( gallery.dataset.ccDuo ) { return; }
		gallery.dataset.ccDuo = '1';
		var imgs = Array.prototype.slice.call( gallery.querySelectorAll( 'figure.wp-block-image img' ) );
		if ( imgs.length < 3 ) { return; }
		var pairs = [];
		for ( var i = 0; i < imgs.length; i += 2 ) { pairs.push( [ imgs[ i ], imgs[ ( i + 1 ) % imgs.length ] ] ); }

		var track = document.createElement( 'div' );
		track.className = 'cc-duo-track';
		var all = [];
		var slots = [ 0, 1 ].map( function ( s ) {
			var slot = document.createElement( 'div' );
			slot.className = 'cc-duo-slot';
			pairs.forEach( function ( p, k ) {
				var src = p[ s ];
				var im = document.createElement( 'img' );
				im.alt = src.alt || '';
				im.decoding = 'async';
				im.loading = 'eager';
				// Defer the download of pairs 2+ until the gallery is near the screen.
				var set = src.getAttribute( 'srcset' );
				var url = src.getAttribute( 'src' );
				if ( k === 0 ) {
					if ( set ) { im.srcset = set; im.sizes = SIZES; }
					im.src = url;
					im.classList.add( 'is-on' );
				} else {
					im.dataset.srcset = set || '';
					im.dataset.src = url;
				}
				slot.appendChild( im );
				all.push( im );
			} );
			track.appendChild( slot );
			return slot;
		} );
		var dots = document.createElement( 'div' );
		dots.className = 'cc-duo-dots';
		dots.setAttribute( 'aria-hidden', 'true' );
		pairs.forEach( function ( p, k ) { var d = document.createElement( 'i' ); if ( !k ) { d.className = 'is-on'; } dots.appendChild( d ); } );
		gallery.appendChild( track );
		gallery.appendChild( dots );
		gallery.classList.add( 'cc-duo-ready' );

		function loadAll() {
			all.forEach( function ( im ) {
				if ( im.dataset.src ) {
					if ( im.dataset.srcset ) { im.srcset = im.dataset.srcset; im.sizes = SIZES; }
					im.src = im.dataset.src;
					delete im.dataset.src;
				}
			} );
		}
		function ready( k ) {
			return slots.every( function ( slot ) { var im = slot.children[ k ]; return im.complete && im.naturalWidth > 0; } );
		}

		var now = 0;
		function show( k ) {
			now = k;
			slots.forEach( function ( slot ) {
				Array.prototype.forEach.call( slot.children, function ( im, x ) { im.classList.toggle( 'is-on', x === now ); } );
			} );
			Array.prototype.forEach.call( dots.children, function ( d, x ) { d.classList.toggle( 'is-on', x === now ); } );
		}

		var motion = !( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
		var visible = false, last = 0;
		function tick( t ) {
			if ( visible && !document.hidden ) {
				if ( !last ) { last = t; }
				if ( t - last >= DELAY ) {
					var next = ( now + 1 ) % pairs.length;
					if ( ready( next ) ) { show( next ); last = t; }
				}
			} else {
				last = 0; // restart the count when it comes back into view
			}
			requestAnimationFrame( tick );
		}

		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) { if ( e.isIntersecting ) { loadAll(); } } );
			}, { rootMargin: '800px 0px' } ).observe( gallery );
			new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) { visible = e.isIntersecting; } );
			}, { threshold: 0.3 } ).observe( gallery );
		} else {
			loadAll(); visible = true;
		}
		if ( motion ) { requestAnimationFrame( tick ); }
	}
	function init() { Array.prototype.forEach.call( document.querySelectorAll( '.wp-block-gallery.is-style-cc-duo' ), setup ); }
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', init ); } else { init(); }
} )();
