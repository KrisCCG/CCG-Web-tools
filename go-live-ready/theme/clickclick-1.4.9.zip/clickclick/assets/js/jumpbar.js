/**
 * Section bar for long pages.
 *
 * In the editor: a list with the style "Section bar (sticky, at top)" whose items link
 * to #sections (the headings get an HTML anchor). On the site that list is hidden and
 * turned into a slim bar right under the header, which stays at the top of the screen
 * while scrolling, highlights the section being read and has a ↑ back-to-top button.
 * On a phone the bar scrolls sideways.
 */
( function () {
	function init() {
		var list = document.querySelector( 'ul.is-style-cc-jumpnav' );
		if ( ! list || ! list.querySelector( 'a[href^="#"]' ) ) {
			return;
		}
		var links = Array.prototype.slice.call( list.querySelectorAll( 'a[href^="#"]' ) );
		var lang = ( document.documentElement.lang || 'en' ).slice( 0, 2 );
		var words = {
			en: [ 'Back to top', 'On this page' ],
			fr: [ 'Retour en haut', 'Sur cette page' ],
			nl: [ 'Terug naar boven', 'Op deze pagina' ]
		}[ lang ] || [ 'Back to top', 'On this page' ];

		var bar = document.createElement( 'nav' );
		bar.className = 'cc-jumpbar';
		bar.setAttribute( 'aria-label', words[ 1 ] );
		var inner = document.createElement( 'div' );
		inner.className = 'cc-jumpbar__inner';
		links.forEach( function ( a ) {
			var b = document.createElement( 'a' );
			b.href = a.getAttribute( 'href' );
			b.textContent = a.textContent;
			inner.appendChild( b );
		} );
		bar.appendChild( inner );
		var up = document.createElement( 'a' );
		up.href = '#';
		up.className = 'cc-jumpbar__top';
		up.setAttribute( 'aria-label', words[ 0 ] );
		up.title = words[ 0 ];
		up.textContent = '↑';
		bar.appendChild( up );

		// Right under the site header, so it is visible from the start and then sticks.
		var header = document.querySelector( 'header.wp-block-template-part' );
		if ( header && header.parentNode ) {
			header.parentNode.insertBefore( bar, header.nextSibling );
		} else {
			document.body.insertBefore( bar, document.body.firstChild );
		}

		up.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			window.scrollTo( { top: 0, behavior: 'smooth' } );
		} );

		// Highlight the section being read.
		var targets = [];
		links.forEach( function ( a ) {
			var t = document.getElementById( a.getAttribute( 'href' ).slice( 1 ) );
			if ( t && targets.indexOf( t ) < 0 ) {
				targets.push( t );
			}
		} );
		var last = null;
		function mark() {
			var y = window.innerHeight * 0.35, cur = null;
			targets.forEach( function ( t ) {
				if ( t.getBoundingClientRect().top <= y ) {
					cur = t.id;
				}
			} );
			if ( cur === last ) {
				return;
			}
			last = cur;
			Array.prototype.forEach.call( inner.querySelectorAll( 'a' ), function ( a ) {
				var on = !! cur && a.getAttribute( 'href' ) === '#' + cur;
				a.classList.toggle( 'is-current', on );
				if ( on && inner.scrollWidth > inner.clientWidth ) {
					inner.scrollTo( { left: a.offsetLeft - 16, behavior: 'smooth' } );
				}
			} );
		}
		var raf;
		window.addEventListener( 'scroll', function () {
			cancelAnimationFrame( raf );
			raf = requestAnimationFrame( mark );
		}, { passive: true } );
		mark();
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
