/*
 * The !! next to the big title (h1).
 * The logo is as high as all title lines together (see style.css). Its width follows from that height,
 * so this script makes room on the left: it tries a space, counts the lines the title then needs,
 * and widens the space until the logo fits. The logo never takes more than 35% of the title width.
 */
( function () {
	var RATIO = 113.17 / 147.5; // width / height of the !! logo
	var CAPS_AND_BASELINE = 0.271; // em, see style.css

	function fitOne( img ) {
		var h1 = img.parentElement;
		var cs = getComputedStyle( h1 );
		var fs = parseFloat( cs.fontSize );
		var lh = parseFloat( cs.lineHeight ) || fs;
		var gap = fs * 0.22;
		var maxPad = h1.clientWidth * 0.35;
		img.style.maxWidth = '';

		function linesWith( pad ) {
			h1.style.paddingLeft = pad + 'px';
			var inner = h1.getBoundingClientRect().height - parseFloat( cs.paddingTop ) - parseFloat( cs.paddingBottom );
			return Math.max( 1, Math.round( inner / lh ) );
		}
		function needFor( lines ) {
			return ( lines * lh - CAPS_AND_BASELINE * fs ) * RATIO + gap;
		}

		var pad = needFor( 1 );
		for ( var i = 0; i < 8; i++ ) {
			if ( pad > maxPad ) { break; }
			var need = needFor( linesWith( pad ) );
			if ( need <= pad + 0.5 ) { break; }
			pad = need;
		}
		if ( pad > maxPad ) {
			pad = maxPad;
			linesWith( pad );
			img.style.maxWidth = ( pad - gap ) + 'px';
			img.style.objectFit = 'contain';
			img.style.objectPosition = 'left top';
		} else {
			// Tighten to the logo's real width at this number of lines.
			var lines = linesWith( pad );
			var exact = needFor( lines );
			if ( linesWith( exact ) !== lines ) { linesWith( pad ); }
		}
	}

	function fit() {
		document.querySelectorAll( 'h1 > img[src*="exclamation-logo"]' ).forEach( fitOne );
	}
	var t;
	window.addEventListener( 'resize', function () { clearTimeout( t ); t = setTimeout( fit, 100 ); } );
	window.addEventListener( 'load', fit );
	if ( document.fonts && document.fonts.ready ) { document.fonts.ready.then( fit ); }
	if ( document.readyState !== 'loading' ) { fit(); } else { document.addEventListener( 'DOMContentLoaded', fit ); }
} )();
