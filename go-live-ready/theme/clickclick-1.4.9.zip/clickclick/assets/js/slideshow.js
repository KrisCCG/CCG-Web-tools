/**
 * Slideshow for galleries with the "Slideshow" style (core/gallery, is-style-cc-slideshow).
 * Adds previous / next arrows and a counter (1 / 19) under the gallery.
 * Swiping works without this script too (CSS scroll-snap).
 */
( function () {
	function setup( gallery ) {
		if ( gallery.dataset.ccSlideshow ) {
			return;
		}
		gallery.dataset.ccSlideshow = '1';
		var slides = Array.prototype.filter.call( gallery.children, function ( el ) {
			return el.matches( 'figure.wp-block-image' );
		} );
		var total = slides.length;
		if ( total < 2 ) {
			return;
		}
		var lang = ( document.documentElement.lang || 'en' ).slice( 0, 2 );
		var words = {
			en: [ 'Previous image', 'Next image' ],
			fr: [ 'Image précédente', 'Image suivante' ],
			nl: [ 'Vorige afbeelding', 'Volgende afbeelding' ]
		}[ lang ] || [ 'Previous image', 'Next image' ];

		var bar = document.createElement( 'div' );
		bar.className = 'cc-slideshow-bar';
		bar.innerHTML =
			'<button type="button" class="cc-slideshow-prev" aria-label="' + words[ 0 ] + '"></button>' +
			'<span class="cc-slideshow-count" aria-live="polite"><span class="cc-now">1</span> / ' + total + '</span>' +
			'<button type="button" class="cc-slideshow-next" aria-label="' + words[ 1 ] + '"></button>';
		gallery.insertAdjacentElement( 'afterend', bar );
		var now = bar.querySelector( '.cc-now' );

		function current() {
			return Math.round( gallery.scrollLeft / Math.max( 1, gallery.clientWidth ) );
		}
		function go( i ) {
			i = ( i + total ) % total;
			gallery.scrollTo( { left: i * gallery.clientWidth, behavior: 'smooth' } );
		}
		bar.querySelector( '.cc-slideshow-prev' ).addEventListener( 'click', function () {
			go( current() - 1 );
		} );
		bar.querySelector( '.cc-slideshow-next' ).addEventListener( 'click', function () {
			go( current() + 1 );
		} );
		gallery.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'ArrowRight' ) { go( current() + 1 ); e.preventDefault(); }
			if ( e.key === 'ArrowLeft' ) { go( current() - 1 ); e.preventDefault(); }
		} );
		var t;
		gallery.addEventListener( 'scroll', function () {
			clearTimeout( t );
			t = setTimeout( function () {
				now.textContent = String( current() + 1 );
			}, 60 );
		}, { passive: true } );
		gallery.setAttribute( 'tabindex', '0' );
	}
	function init() {
		document.querySelectorAll( '.wp-block-gallery.is-style-cc-slideshow' ).forEach( setup );
	}
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();

/**
 * Slideshow photos are shown whole ("contain") so portrait photos are not cut off.
 * A photo whose shape is close to the frame (within 15 %) fills it instead ("cover"),
 * so it gets the rounded corners and no thin empty band.
 */
( function () {
	function fit( img ) {
		var fig = img.closest( 'figure' );
		if ( !img.naturalWidth || !fig ) { return; }
		var box = fig.getBoundingClientRect();
		if ( !box.height ) { return; }
		var r = ( img.naturalWidth / img.naturalHeight ) / ( box.width / box.height );
		img.classList.toggle( 'cc-fill', r > 0.85 && r < 1.15 );
	}
	function init() {
		document.querySelectorAll( '.wp-block-gallery.is-style-cc-slideshow figure.wp-block-image img' ).forEach( function ( img ) {
			if ( img.complete ) { fit( img ); } else { img.addEventListener( 'load', function () { fit( img ); } ); }
		} );
	}
	if ( document.readyState === 'loading' ) { document.addEventListener( 'DOMContentLoaded', init ); } else { init(); }
	window.addEventListener( 'resize', init );
} )();
